# AuthSystem
An account authentication system. The public endpoints are anything in accountRouter, which allow no authentication to request them.

# Features
- Account Login (/account/login)
- Account Signup (/account/signup)
- Account Updates (/auth/account)
- JWT
- Roles
- Role Permissions

#

>