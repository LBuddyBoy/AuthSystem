const role = {
    id: 1,
    created_at: "2025-06-20T15:47:31.388Z",
    name: "Member",
    weight: 100,
    icon: "Member",
    staff: false,
    permissions: ["test1", "test2"],
    inheritance: []
};

console.log(JSON.stringify(role));